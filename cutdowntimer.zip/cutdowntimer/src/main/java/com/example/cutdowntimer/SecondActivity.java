package com.example.cutdowntimer;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

/**
 * Created by 郏小康 on 2020/1/17.
 */

public class SecondActivity extends AppCompatActivity {

    //第一步：声明控件
    //private TimePicker timePicker;
    //private Button buttonTimemode;
    //private Button buttonTimepickmode;
    //private Button buttonGettime;
    //private TextView textViewTime;

    private DatePicker datePicker;
    //private Button buttonDadepickmode;
    private Button buttonGetdate;
    private TextView textViewDate;

    private Button buttonSubmit;

    private int years=0,months=0,days=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        //第二步：找到控件
        //timePicker = (TimePicker) findViewById(R.id.L7_timepick);
        //buttonTimemode = (Button) findViewById(R.id.L7_bt_timemode);
        //buttonTimepickmode = (Button) findViewById(R.id.L7_timepickmode);
        //buttonGettime = (Button) findViewById(R.id.L7_bt_gettime);
        //textViewTime = (TextView) findViewById(R.id.L7_texttime);

        datePicker = (DatePicker) findViewById(R.id.L7_datapick);
        //buttonDadepickmode = (Button) findViewById(R.id.L7_bt_dadepicmode);
        buttonGetdate = (Button) findViewById(R.id.L7_bt_getdate);
        textViewDate = (TextView) findViewById(R.id.L7_textdate);

        buttonSubmit= (Button) findViewById(R.id.btn_submitTime);

        //第四步：设置监听器
        //timePicker.setOnTimeChangedListener(new TimeListener());
        //buttonTimemode.setOnClickListener(new ButtonListnner());
        //buttonGettime.setOnClickListener(new ButtonListnner());
        buttonGetdate.setOnClickListener(new ButtonListnner());
        buttonSubmit.setOnClickListener(new ButtonListnner());

    }

    //第三步：实现监听器函数接口
    //class TimeListener implements TimePicker.OnTimeChangedListener{
    //    @Override
    //    public void onTimeChanged(TimePicker view, int hourOfDay, int minute) {
    //        System.out.println("Hour:" + hourOfDay + ",minute:" + minute);
    //        textViewTime.setText(hourOfDay + ":" + minute);
    //    }
    //}

    class ButtonListnner implements View.OnClickListener{

        @RequiresApi(api = Build.VERSION_CODES.M)
        @Override
        public void onClick(View v) {
            switch(v.getId())
            {
                //case R.id.L7_bt_timemode:
                //    if(buttonTimemode.getText().toString().contains("12")){
                //        timePicker.setIs24HourView(false);
                //        buttonTimemode.setText("24小时制");
                //    }
                //    else{
                //        timePicker.setIs24HourView(true);
                //        buttonTimemode.setText("12小时制");
                //    }
                //    break;

                //case R.id.L7_bt_gettime:
                //    int hour = timePicker.getCurrentHour();
                //    int minute = timePicker.getCurrentMinute();
                //    textViewTime.setText(hour + ":" + minute);
                //    break;

                case R.id.L7_bt_getdate:
                    int year = datePicker.getYear();
                    int month = datePicker.getMonth()+1;
                    int day = datePicker.getDayOfMonth();

                    textViewDate.setText(year + " - " + month + " - " + day);
                    years=year;
                    months=month;
                    days=day;
                    break;

                case R.id.btn_submitTime:
                    try{
                        SharedPreferences preferences = getSharedPreferences("IpAndPort",MainActivity.MODE_PRIVATE);
                        SharedPreferences.Editor editor = preferences.edit();
                        editor.putString("StoDesYear",String.valueOf(years));
                        editor.putString("StoDesMonth",String.valueOf(months));
                        editor.putString("StoDesDay",String.valueOf(days));
                        editor.commit();//写入
                    }catch (Exception e){

                    }

                    //Intent intent=new Intent(SecondActivity.this,MainActivity.class);
                    //创建并实例化一个Bundle对象
                    //Bundle bundle=new Bundle();
                    //bundle.putInt("year",years);
                    //bundle.putInt("month",months);
                    //bundle.putInt("day",days);
                    //intent.putExtras(bundle);//将Bundle对象添加到Intent对象中
                    //startActivity(intent);//启动Activity

                    // 广播通知
                    Intent intent = new Intent();
                    intent.setAction("action.refreshFriend");
                    sendBroadcast(intent);
                    SecondActivity.this.finish();
                    break;
            }
        }
    }

}
