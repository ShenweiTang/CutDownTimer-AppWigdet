package com.example.cutdowntimer;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class MainActivity extends AppCompatActivity {

    EditText edit_label;
    Button btn_confirm,btn_edit_date;
    int year=0,month=0,day=0;
    String DesYear="";
    String DesMonth="";
    String DesDay="";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction("action.refreshFriend");
        registerReceiver(mRefreshBroadcastReceiver,intentFilter);

        edit_label= (EditText) findViewById(R.id.edit_label);
        btn_edit_date= (Button) findViewById(R.id.btn_edit_date);
        btn_confirm= (Button) findViewById(R.id.btn_confirm);

        try{
            SharedPreferences preferences = getSharedPreferences("IpAndPort",MainActivity.MODE_PRIVATE);
            DesYear = preferences.getString("StoDesYear", "2010");
            DesMonth=preferences.getString("StoDesMonth","05");
            DesDay=preferences.getString("StoDesDay","31");
            edit_label.setText(preferences.getString("StoDesLabel"," "));

            //Intent intent1=getIntent();//获取Intent对象
            //Bundle bundle=intent1.getExtras();//获取传递的Bundle信息
            //year=bundle.getInt("year");
            //month=bundle.getInt("month");
            //day=bundle.getInt("day");

            //DesYear=String.valueOf(year);

            month=Integer.parseInt(DesMonth);
            day=Integer.parseInt(DesDay);

            if (month < 10) {
                DesMonth = "0" + String.valueOf(month);
            } else {
                //DesMonth = String.valueOf(month);
            }

            if (day < 10) {
                DesDay = "0" + String.valueOf(day);
            } else {
                //DesDay = String.valueOf(day);
            }

            btn_edit_date.setText(DesYear+" - "+DesMonth+" - "+DesDay);

        }catch (Exception e) {
            btn_edit_date.setText(DesYear+" - "+DesMonth+" - "+DesDay);
            //btn_edit_date.setText("Please set date time!");
        }


        btn_confirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try{
                    DateFormat df=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

                    Calendar cl=Calendar.getInstance();
                    String cYear=String.valueOf(cl.get(Calendar.YEAR));
                    String cMonth="";
                    String cDay="";

                    if (cl.get(Calendar.MONTH) < 10) {
                        cMonth = "0" + String.valueOf(cl.get(Calendar.MONTH)+1);
                    } else {
                        cMonth = String.valueOf(cl.get(Calendar.MONTH)+1);
                    }

                    if (cl.get(Calendar.DAY_OF_MONTH) < 10) {
                        cDay = "0" + String.valueOf(cl.get(Calendar.DAY_OF_MONTH));
                    } else {
                        cDay = String.valueOf(cl.get(Calendar.DAY_OF_MONTH));
                    }


                    Date startTime = df.parse(cYear+"-"+cMonth+"-"+cDay+" 12:10:10");
                    Date endTime = df.parse(DesYear+"-"+DesMonth+"-"+DesDay+" 14:10:10");

                    long diff =  endTime.getTime()-startTime.getTime();
                    long days = diff / (1000 * 60 * 60 * 24);
                    //long hours = (diff-days*(1000 * 60 * 60 * 24))/(1000* 60 * 60);
                    //long minutes = (diff-days*(1000 * 60 * 60 * 24)-hours*(1000* 60 * 60))/(1000* 60);
                    AlertDialog.Builder builder=new AlertDialog.Builder(MainActivity.this);
                    builder.setTitle(edit_label.getText());
                    builder.setMessage("剩余天数为："+days+"天！");
                    builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            Toast.makeText(MainActivity.this, "嘻嘻嘻",Toast.LENGTH_SHORT).show();
                        }
                    });
                    builder.show();
                }catch (Exception e){

                }

                try{
                    SharedPreferences preferences = getSharedPreferences("IpAndPort",MainActivity.MODE_PRIVATE);
                    SharedPreferences.Editor editor = preferences.edit();
                    editor.putString("StoDesYear",DesYear);
                    editor.putString("StoDesMonth",DesMonth);
                    editor.putString("StoDesDay",DesDay);
                    editor.putString("StoDesLabel", String.valueOf(edit_label.getText()));
                    editor.commit();//写入

                    Intent intent=new Intent();
                    intent.setAction("com.xxx.verify");
                    sendBroadcast(intent);//发送广播
                }catch (Exception e){

                }
                Toast.makeText(MainActivity.this,"成功啦！",Toast.LENGTH_SHORT).show();
            }
        });

        btn_edit_date.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent();
                intent.setClass(MainActivity.this,SecondActivity.class);
                startActivity(intent);
                //MainActivity.this.finish();
            }
        });
    }

    private BroadcastReceiver mRefreshBroadcastReceiver=new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String action=intent.getAction();
            if (action.equals("action.refreshFriend")){
                try{
                    //Toast.makeText(MainActivity.this,"Yess,I received",Toast.LENGTH_LONG).show();
                    SharedPreferences preferences = getSharedPreferences("IpAndPort",MainActivity.MODE_PRIVATE);
                    DesYear = preferences.getString("StoDesYear", "2010");
                    DesMonth=preferences.getString("StoDesMonth","05");
                    DesDay=preferences.getString("StoDesDay","31");

                    month=Integer.parseInt(DesMonth);
                    day=Integer.parseInt(DesDay);

                    if (month < 10) {
                        DesMonth = "0" + String.valueOf(month);
                    } else {
                        //DesMonth = String.valueOf(month);
                    }

                    if (day < 10) {
                        DesDay = "0" + String.valueOf(day);
                    } else {
                        //DesDay = String.valueOf(day);
                    }

                    btn_edit_date.setText(DesYear+" - "+DesMonth+" - "+DesDay);

                }catch (Exception e){

                }
            }
        }
    };
}
